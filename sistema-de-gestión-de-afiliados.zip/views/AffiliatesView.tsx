// FIX: Implemented the AffiliatesView component to manage and display affiliates, resolving the 'not a module' error. The component includes state management, data fetching, filtering, and a modal for creating/editing affiliates.
import React, { useState, useEffect, useMemo } from 'react';
import { Affiliate, User } from '../types';
import { firebaseService } from '../services/firebaseService';
import Spinner from '../components/ui/Spinner';
import AffiliateTable from '../components/affiliates/AffiliateTable';
import AffiliateForm from '../components/affiliates/AffiliateForm';
import Modal from '../components/ui/Modal';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import AffiliateDetailView from './AffiliateDetailView';

interface AffiliatesViewProps {
  user: User;
}

const ITEMS_PER_PAGE = 20;

const AffiliatesView: React.FC<AffiliatesViewProps> = ({ user }) => {
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAffiliate, setSelectedAffiliate] = useState<Affiliate | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');
  const [affiliateForDetail, setAffiliateForDetail] = useState<Affiliate | null>(null);


  useEffect(() => {
    try {
      const unsubscribe = firebaseService.onAffiliatesSnapshot(data => {
        setAffiliates(data);
        setError(null);
        setLoading(false);
      });
      return () => unsubscribe();
    } catch (err) {
      setError('No se pudieron cargar los afiliados.');
      console.error(err);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);
  
  const handleOpenModalForCreate = () => {
    setSelectedAffiliate(null);
    setIsModalOpen(true);
  };
  
  const handleOpenModalForEdit = (affiliate: Affiliate) => {
    setSelectedAffiliate(affiliate);
    setIsModalOpen(true);
  };

  const handleViewDetails = (affiliate: Affiliate) => {
    setAffiliateForDetail(affiliate);
    setViewMode('detail');
  };

  const handleBackToList = () => {
    setAffiliateForDetail(null);
    setViewMode('list');
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedAffiliate(null);
  };

  const filteredAffiliates = useMemo(() => {
    const lowercasedFilter = searchTerm.trim().toLowerCase();
    if (!lowercasedFilter) {
      return affiliates;
    }
    return affiliates.filter(affiliate =>
      affiliate.fullName.toLowerCase().includes(lowercasedFilter) ||
      affiliate.email.toLowerCase().includes(lowercasedFilter) ||
      affiliate.id.toLowerCase().includes(lowercasedFilter)
    );
  }, [affiliates, searchTerm]);

  const totalPages = Math.ceil(filteredAffiliates.length / ITEMS_PER_PAGE);
  const paginatedAffiliates = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredAffiliates.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredAffiliates, currentPage]);

  const handleNextPage = () => {
    setCurrentPage(prev => Math.min(prev + 1, totalPages));
  };

  const handlePrevPage = () => {
    setCurrentPage(prev => Math.max(prev - 1, 1));
  };

  if (loading) return <Spinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  if (viewMode === 'detail' && affiliateForDetail) {
    return <AffiliateDetailView affiliate={affiliateForDetail} onBack={handleBackToList} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Gestión de Afiliados</h1>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex-grow md:flex-grow-0">
             <Input
                id="search"
                label=""
                placeholder="Buscar por nombre, email, ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-64"
             />
          </div>
          {user.role === 'admin' && (
             <Button onClick={handleOpenModalForCreate}>
                + Nuevo Afiliado
             </Button>
          )}
        </div>
      </div>
      
      <AffiliateTable 
        affiliates={paginatedAffiliates} 
        onEdit={handleOpenModalForEdit}
        onViewDetails={handleViewDetails}
        user={user} 
      />

      {totalPages > 1 && (
        <div className="flex justify-center items-center space-x-4 mt-4">
          <Button 
            onClick={handlePrevPage} 
            disabled={currentPage === 1}
            variant="secondary"
          >
            Anterior
          </Button>
          <span className="text-sm font-medium text-gray-700">
            Página {currentPage} de {totalPages}
          </span>
          <Button 
            onClick={handleNextPage} 
            disabled={currentPage === totalPages}
            variant="secondary"
          >
            Siguiente
          </Button>
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal}
        title={selectedAffiliate ? 'Editar Afiliado' : 'Nuevo Afiliado'}
      >
        <AffiliateForm
          affiliate={selectedAffiliate}
          onFinished={handleCloseModal}
          onCancel={handleCloseModal}
          user={user}
        />
      </Modal>

    </div>
  );
};

export default AffiliatesView;